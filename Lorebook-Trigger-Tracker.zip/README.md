# Lorebook Trigger Tracker

A small SillyTavern extension that shows which World Info / Lorebook entries were activated by the latest generation.

## Current features

- Small `◉` button above the chat input, near the lower-left corner.
- Badge such as `◉8` showing the number of activated entries.
- Click the button to open a compact WORLD INFO panel.
- Groups entries by lorebook name when SillyTavern provides the complete World Info list.
- Marks activated entries with `✓` and non-activated loaded entries with `✗`.
- Uses SillyTavern's `WORLD_INFO_ACTIVATED` event for the actual activation result rather than running a second keyword scan.

## Install from Git

In SillyTavern: Extensions -> Install Extension -> paste this repository URL.

The extension files are:

- `index.js`
- `style.css`
- `manifest.json`

## Notes

The `Trigger:` line currently displays the entry's configured primary key(s), not a claim that a particular key was the exact key that matched. SillyTavern's activation event exposes the activated entry, but not a per-entry matched-key field. This avoids falsely reporting a keyword for regex, recursion, vector, constant, or other activation paths.

## License

MIT
