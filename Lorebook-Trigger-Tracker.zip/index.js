import { eventSource, event_types } from '../../../../script.js';

const EXTENSION_NAME = 'Lorebook Trigger Tracker';
const ROOT_ID = 'lorebook-trigger-tracker';

let activeEntries = [];
let loadedEntries = [];
let panelOpen = false;

function entryId(entry) {
    return `${entry?.world ?? ''}::${entry?.uid ?? entry?.id ?? entry?.comment ?? entry?.key?.join('|') ?? Math.random()}`;
}

function entryTitle(entry) {
    return (entry?.comment || entry?.name || (Array.isArray(entry?.key) ? entry.key.join(', ') : '') || `Entry ${entry?.uid ?? ''}`).trim();
}

function entryKeys(entry) {
    if (!Array.isArray(entry?.key)) return [];
    return entry.key.filter(Boolean).map(String);
}

function triggerText(entry) {
    const keys = entryKeys(entry);
    if (!keys.length) {
        if (entry?.constant) return 'Constant';
        if (entry?.vectorized) return 'Vector match';
        return '—';
    }
    return keys.length === 1 ? `"${keys[0]}"` : keys.map(k => `"${k}"`).join(', ');
}

function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
    }[char]));
}

function ensureUi() {
    if (document.getElementById(ROOT_ID)) return;

    const root = document.createElement('div');
    root.id = ROOT_ID;
    root.innerHTML = `
        <button class="lbtt-button" type="button" aria-label="Lorebook triggers" aria-expanded="false">
            <span class="lbtt-mark">◉</span><span class="lbtt-badge">0</span>
        </button>
        <section class="lbtt-panel" aria-hidden="true">
            <div class="lbtt-panel-head">
                <span>WORLD INFO</span>
                <button class="lbtt-close" type="button" aria-label="Close">×</button>
            </div>
            <div class="lbtt-rule">━━━━━━━━━━━━━━━━━━</div>
            <div class="lbtt-content"></div>
        </section>
    `;

    document.body.appendChild(root);

    root.querySelector('.lbtt-button').addEventListener('click', () => {
        panelOpen = !panelOpen;
        root.classList.toggle('lbtt-open', panelOpen);
        root.querySelector('.lbtt-button').setAttribute('aria-expanded', String(panelOpen));
        root.querySelector('.lbtt-panel').setAttribute('aria-hidden', String(!panelOpen));
        if (panelOpen) renderPanel();
    });

    root.querySelector('.lbtt-close').addEventListener('click', () => {
        panelOpen = false;
        root.classList.remove('lbtt-open');
        root.querySelector('.lbtt-button').setAttribute('aria-expanded', 'false');
        root.querySelector('.lbtt-panel').setAttribute('aria-hidden', 'true');
    });

    renderPanel();
}

function updateBadge() {
    const root = document.getElementById(ROOT_ID);
    if (!root) return;
    const badge = root.querySelector('.lbtt-badge');
    const count = activeEntries.length;
    badge.textContent = count > 99 ? '99+' : String(count);
    badge.classList.toggle('lbtt-hidden', count === 0);
}

function groupEntries(entries) {
    const groups = new Map();
    for (const entry of entries) {
        const world = entry?.world || 'WORLD INFO';
        if (!groups.has(world)) groups.set(world, []);
        groups.get(world).push(entry);
    }
    return groups;
}

function renderPanel() {
    const root = document.getElementById(ROOT_ID);
    if (!root) return;

    const content = root.querySelector('.lbtt-content');
    const activeIds = new Set(activeEntries.map(entryId));

    if (!loadedEntries.length && !activeEntries.length) {
        content.innerHTML = `<div class="lbtt-empty">No World Info data yet.<br><small>Generate a message first.</small></div>`;
        updateBadge();
        return;
    }

    // Prefer the complete list from WORLDINFO_ENTRIES_LOADED.
    // If it is unavailable, show only the entries ST reported as activated.
    const source = loadedEntries.length ? loadedEntries : activeEntries;
    const groups = groupEntries(source);

    let html = '';

    for (const [world, entries] of groups) {
        html += `<div class="lbtt-world">${escapeHtml(world)}</div>`;

        for (const entry of entries) {
            const active = activeIds.has(entryId(entry));
            const title = entryTitle(entry);
            const trigger = active ? triggerText(entry) : 'No trigger';

            html += `
                <div class="lbtt-entry ${active ? 'is-active' : 'is-inactive'}">
                    <div class="lbtt-status">${active ? '✓' : '✗'}</div>
                    <div class="lbtt-entry-body">
                        <div class="lbtt-entry-title">${escapeHtml(title)}</div>
                        <div class="lbtt-trigger">
                            ${active
                                ? `<span>Trigger: ${escapeHtml(trigger)}</span>`
                                : `<span>No trigger</span>`}
                        </div>
                        ${active && entry?.uid != null
                            ? `<div class="lbtt-uid">Entry: #${escapeHtml(entry.uid)}</div>`
                            : ''}
                    </div>
                </div>
            `;
        }
    }

    content.innerHTML = html || `<div class="lbtt-empty">No World Info entries found.</div>`;
    updateBadge();
}

function normalizeLoadedPayload(payload) {
    // Current ST emits an object with the relevant lore arrays.
    if (!payload || typeof payload !== 'object') return [];

    const result = [];
    const seen = new Set();

    for (const key of ['globalLore', 'characterLore', 'chatLore', 'personaLore']) {
        const list = Array.isArray(payload[key]) ? payload[key] : [];
        for (const entry of list) {
            if (!entry) continue;
            const id = entryId(entry);
            if (seen.has(id)) continue;
            seen.add(id);
            result.push(entry);
        }
    }

    // Graceful fallback for variants that emit a flat array.
    if (!result.length && Array.isArray(payload)) {
        for (const entry of payload) {
            if (!entry) continue;
            const id = entryId(entry);
            if (seen.has(id)) continue;
            seen.add(id);
            result.push(entry);
        }
    }

    return result;
}

function bindEvents() {
    eventSource.on(event_types.WORLDINFO_ENTRIES_LOADED, payload => {
        loadedEntries = normalizeLoadedPayload(payload);
        renderPanel();
    });

    eventSource.on(event_types.WORLD_INFO_ACTIVATED, entryList => {
        activeEntries = Array.isArray(entryList) ? [...entryList] : [];
        renderPanel();
        updateBadge();
    });
}

async function init() {
    ensureUi();
    bindEvents();
}

init();
